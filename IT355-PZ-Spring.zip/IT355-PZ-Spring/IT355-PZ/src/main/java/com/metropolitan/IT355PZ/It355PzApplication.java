package com.metropolitan.IT355PZ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class It355PzApplication {

    public static void main(String[] args) {
        SpringApplication.run(It355PzApplication.class, args);
    }

}